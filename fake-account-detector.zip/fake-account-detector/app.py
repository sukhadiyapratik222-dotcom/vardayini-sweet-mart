"""
app.py
Flask application exposing the detection engine as a small SOC-style
dashboard, plus the "report to central agency" workflow described in the
problem statement (PS-SW-003): once a tool flags an account, a designated
central agency needs a record it can act on (approach the platform for
suspension / pursue legal action).

This prototype simulates the central agency queue with a local JSON case
log (case_log.json). In production this endpoint would instead call the
agency's case-management API / ticketing system.
"""
import csv
import io
import json
import os
import uuid
from datetime import datetime, timezone

from flask import Flask, jsonify, request, send_file, render_template

from detector import RawAccount, assess_account, FEATURE_COLUMNS  # noqa: F401

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
CASE_LOG_PATH = os.path.join(BASE_DIR, "case_log.json")

app = Flask(__name__)


def _load_cases():
    if not os.path.exists(CASE_LOG_PATH):
        return []
    with open(CASE_LOG_PATH, "r") as fh:
        return json.load(fh)


def _save_cases(cases):
    with open(CASE_LOG_PATH, "w") as fh:
        json.dump(cases, fh, indent=2)


@app.route("/")
def index():
    return render_template("index.html")


@app.route("/api/scan", methods=["POST"])
def scan():
    payload = request.get_json(force=True) or {}
    try:
        raw = RawAccount(
            username=payload.get("username", "").strip() or "unknown_user",
            display_name=payload.get("display_name", ""),
            account_age_days=float(payload.get("account_age_days", 365)),
            followers=int(payload.get("followers", 0)),
            following=int(payload.get("following", 0)),
            posts_count=int(payload.get("posts_count", 0)),
            has_profile_pic=bool(payload.get("has_profile_pic", True)),
            bio=payload.get("bio", ""),
            avg_posts_per_day=float(payload.get("avg_posts_per_day", 0.5)),
            engagement_rate=float(payload.get("engagement_rate", 0.05)),
            account_uses_stock_photo=bool(payload.get("account_uses_stock_photo", False)),
            recent_username_changes=int(payload.get("recent_username_changes", 0)),
            platform=payload.get("platform", "generic"),
        )
    except (ValueError, TypeError) as exc:
        return jsonify({"error": f"Invalid input: {exc}"}), 400

    result = assess_account(raw)
    return jsonify(result.to_dict())


@app.route("/api/report", methods=["POST"])
def report():
    """Push a flagged account into the central-agency case log."""
    payload = request.get_json(force=True) or {}
    assessment = payload.get("assessment")
    if not assessment:
        return jsonify({"error": "assessment payload is required"}), 400

    case = {
        "case_id": str(uuid.uuid4())[:8],
        "reported_at": datetime.now(timezone.utc).isoformat(),
        "status": "Pending Agency Review",
        **assessment,
    }
    cases = _load_cases()
    cases.insert(0, case)
    _save_cases(cases)
    return jsonify(case), 201


@app.route("/api/reports", methods=["GET"])
def list_reports():
    return jsonify(_load_cases())


@app.route("/api/reports/<case_id>/status", methods=["POST"])
def update_status(case_id):
    payload = request.get_json(force=True) or {}
    new_status = payload.get("status")
    if new_status not in {
        "Pending Agency Review",
        "Escalated to Platform",
        "Account Suspended",
        "Dismissed - False Positive",
    }:
        return jsonify({"error": "invalid status"}), 400
    cases = _load_cases()
    for c in cases:
        if c["case_id"] == case_id:
            c["status"] = new_status
            _save_cases(cases)
            return jsonify(c)
    return jsonify({"error": "case not found"}), 404


@app.route("/api/reports/export", methods=["GET"])
def export_reports():
    cases = _load_cases()
    buf = io.StringIO()
    if cases:
        fieldnames = list(cases[0].keys())
        writer = csv.DictWriter(buf, fieldnames=fieldnames)
        writer.writeheader()
        for c in cases:
            row = dict(c)
            if isinstance(row.get("reasons"), list):
                row["reasons"] = "; ".join(row["reasons"])
            if isinstance(row.get("top_model_factors"), list):
                row["top_model_factors"] = "; ".join(row["top_model_factors"])
            writer.writerow(row)
    mem = io.BytesIO(buf.getvalue().encode("utf-8"))
    mem.seek(0)
    return send_file(
        mem,
        mimetype="text/csv",
        as_attachment=True,
        download_name="flagged_accounts_report.csv",
    )


if __name__ == "__main__":
    app.run(debug=True, port=5000)
